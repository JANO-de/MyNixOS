-- MONITOR CONFIG
hl.monitor({
    output = "",
    mode = "preferred",
    position = "auto",
    scale = "1"
})

-- Window and workspace gestures
hl.gesture({
    fingers = 4,
    direction = "swipe",
    action = "move"
})
hl.gesture({
    fingers = 4,
    direction = "pinch",
    action = "float"
})
hl.gesture({
    fingers = 3,
    direction = "horizontal",
    action = "workspace"
})

-- Scratchpad gestures
-- Canonical pair: toggle_special("special") and workspace "special:special" both
-- resolve the workspace by name, so they always target the same workspace ID.
-- (A bare "special" move target bypasses the name lookup and can create a second
-- workspace with the same name but a different ID.)
local SCRATCH_TOGGLE = "special"
local SCRATCH_WS = "special:special"

-- Window object, not an address string: the weak ref expires when the window
-- closes (fields read as nil), whereas addresses are heap pointers that can be
-- reused by a later window.
local last_sent = nil

local function in_scratchpad(win)
    local ws = win and win.workspace
    return ws ~= nil and ws.name == SCRATCH_WS
end

-- Manual filter instead of hl.get_windows({ workspace = ... }): resolving a
-- workspace selector can create the workspace as a side effect.
local function any_scratchpad_window()
    for _, w in ipairs(hl.get_windows()) do
        if in_scratchpad(w) then return w end
    end
    return nil
end

local function show_scratchpad_and_refocus()
    hl.dispatch(hl.dsp.workspace.toggle_special(SCRATCH_TOGGLE))
    if in_scratchpad(last_sent) then
        hl.dispatch(hl.dsp.focus({ window = last_sent }))
    else
        last_sent = nil
    end
end

local function handle_scratchpad_gesture(direction)
    local monitor = hl.get_active_monitor()
    if not monitor then return end

    local special = monitor.active_special_workspace
    local scratch_visible = special ~= nil and special.name == SCRATCH_WS

    if direction == "up" then
        if scratch_visible then
            local win = hl.get_active_window()
            if in_scratchpad(win) then
                -- Retrieve the focused window to the regular workspace; the
                -- scratchpad auto-hides via binds:hide_special_on_workspace_change.
                if monitor.active_workspace then
                    hl.dispatch(hl.dsp.window.move({ workspace = monitor.active_workspace, window = win }))
                    if last_sent and last_sent.address == win.address then
                        last_sent = nil
                    end
                end
            else
                -- Focus is on a regular window below the overlay: focus the
                -- scratchpad (last-sent window if still there, else any of its
                -- windows); if the scratchpad is empty, hide it.
                local target = in_scratchpad(last_sent) and last_sent or any_scratchpad_window()
                if target then
                    hl.dispatch(hl.dsp.focus({ window = target }))
                else
                    hl.dispatch(hl.dsp.workspace.toggle_special(SCRATCH_TOGGLE))
                end
            end
        else
            -- Also replaces any other visible special workspace with the scratchpad.
            show_scratchpad_and_refocus()
        end
    elseif direction == "down" then
        if special then
            -- Hide whichever special workspace is visible (name is "special:<name>").
            hl.dispatch(hl.dsp.workspace.toggle_special(string.sub(special.name, 9)))
        else
            local win = hl.get_active_window()
            if win then
                hl.dispatch(hl.dsp.window.move({ workspace = SCRATCH_WS, window = win, follow = false }))
                -- Record only if the move actually landed the window there.
                if in_scratchpad(win) then
                    last_sent = win
                end
            end
        end
    end
end

hl.gesture({
    fingers = 3,
    direction = "up",
    action = function()
        handle_scratchpad_gesture("up")
    end
})
hl.gesture({
    fingers = 3,
    direction = "down",
    action = function()
        handle_scratchpad_gesture("down")
    end
})

hl.config({
    gestures = {
        workspace_swipe_distance = 700,
        workspace_swipe_cancel_ratio = 0.2,
        workspace_swipe_min_speed_to_force = 5,
        workspace_swipe_direction_lock = true,
        workspace_swipe_direction_lock_threshold = 10,
        workspace_swipe_create_new = true
    },
    general = {
        -- Gaps and border
        gaps_in = 10,
        gaps_out = 11,
        gaps_workspaces = 50,

        border_size = 3,

        col = {
            active_border = "rgba(f61680FF)",
            inactive_border = "rgba(31313600)"
        },
        resize_on_border = true,

        no_focus_fallback = true,
        allow_tearing = true, -- This just allows the `immediate` window rule to work
        snap = {
            enabled = true,
            window_gap = 4,
            monitor_gap = 5,
            respect_gaps = true
        }
    },
    decoration = {
        -- 2 = circle, higher = squircle, 4 = very obvious squircle
        -- Fuck clearly visible squircles. 100% Apple brainrot.
        rounding_power = 4,
        rounding = 18,

        blur = {
            enabled = true,
            xray = false,
            -- Let Hyprland blur the desktop behind special workspaces (the scratchpad).
            -- This is compositor-side blur, so the background stays smooth without
            -- creating a fullscreen blur window in Quickshell.
            special = true,
            new_optimizations = true,
            size = 10,
            passes = 3,
            brightness = 1,
            noise = 0.05,
            contrast = 0.89,
            vibrancy = 0.2,
            vibrancy_darkness = 0.2,
            popups = false,
            popups_ignorealpha = 0.6,
            input_methods = true,
            input_methods_ignorealpha = 0.8
        },
        shadow = {
            enabled = true,
            range = 20,
            offset = {0, 2},
            render_power = 4,
            color = "rgba(00000020)"

        },
        -- Dim
        dim_inactive = true,
        dim_strength = 0.05,
        dim_special = 0.2
    },
    animations = {
        enabled = true
    },
    dwindle = {
        preserve_split = true,
        smart_split = false,
        smart_resizing = false
        -- precise_mouse_move = true,
    },
})
-- Curves
hl.curve("expressiveFastSpatial", {
    type = "bezier",
    points = {{0.42, 1.67}, {0.21, 0.90}}
})
hl.curve("expressiveSlowSpatial", {
    type = "bezier",
    points = {{0.39, 1.29}, {0.35, 0.98}}
})
hl.curve("expressiveDefaultSpatial", {
    type = "bezier",
    points = {{0.38, 1.21}, {0.22, 1.00}}
})
hl.curve("emphasizedDecel", {
    type = "bezier",
    points = {{0.05, 0.7}, {0.1, 1}}
})
hl.curve("emphasizedAccel", {
    type = "bezier",
    points = {{0.3, 0}, {0.8, 0.15}}
})
hl.curve("standardDecel", {
    type = "bezier",
    points = {{0, 0}, {0, 1}}
})
hl.curve("menu_decel", {
    type = "bezier",
    points = {{0.1, 1}, {0, 1}}
})
hl.curve("menu_accel", {
    type = "bezier",
    points = {{0.52, 0.03}, {0.72, 0.08}}
})
hl.curve("stall", {
    type = "bezier",
    points = {{1, -0.1}, {0.7, 0.85}}
})
hl.curve("iiAppOpen", {
    type = "bezier",
    points = {{0.05, 0.9}, {0.1, 1}}
})
-- Configs
-- windows
hl.animation({
    leaf = "windowsIn",
    enabled = true,
    speed = 3.2,
    bezier = "iiAppOpen",
    style = "popin 20%"
})
hl.animation({
    leaf = "fadeIn",
    enabled = true,
    speed = 3.2,
    bezier = "iiAppOpen"
})
hl.animation({
    leaf = "windowsOut",
    enabled = true,
    speed = 3.2,
    bezier = "iiAppOpen",
    style = "popin 60%"
})
hl.animation({
    leaf = "fadeOut",
    enabled = true,
    speed = 3.2,
    bezier = "iiAppOpen"
})
hl.animation({
    leaf = "windowsMove",
    enabled = true,
    speed = 3,
    bezier = "emphasizedDecel",
    style = "slide"
})
hl.animation({
    leaf = "border",
    enabled = true,
    speed = 10,
    bezier = "emphasizedDecel"
})

-- layers
hl.animation({
    leaf = "layersIn",
    enabled = true,
    speed = 2.7,
    bezier = "emphasizedDecel",
    style = "popin 93%"
})
hl.animation({
    leaf = "layersOut",
    enabled = true,
    speed = 2.4,
    bezier = "menu_accel",
    style = "popin 94%"
})
-- fade
hl.animation({
    leaf = "fadeLayersIn",
    enabled = true,
    speed = 2.7,
    bezier = "stall"
})
hl.animation({
    leaf = "fadeLayersOut",
    enabled = true,
    speed = 2.7,
    bezier = "stall"
})
-- workspaces
hl.animation({
    leaf = "workspaces",
    enabled = true,
    speed = 7,
    bezier = "menu_decel",
    style = "slide"
})
-- specialWorkspace
hl.animation({
    leaf = "specialWorkspaceIn",
    enabled = true,
    speed = 2.8,
    bezier = "emphasizedDecel",
    style = "slidevert"
})
hl.animation({
    leaf = "specialWorkspaceOut",
    enabled = true,
    speed = 1.2,
    bezier = "emphasizedAccel",
    style = "slidevert"
})
-- zoom
hl.animation({
    leaf = "zoomFactor",
    enabled = true,
    speed = 3,
    bezier = "standardDecel"
})

hl.config({
    input = {
        kb_layout = "us",
        numlock_by_default = true,
        repeat_delay = 250,
        repeat_rate = 35,

        follow_mouse = 1,
        off_window_axis_events = 2,

        touchpad = {
            natural_scroll = true,
            disable_while_typing = true,
            clickfinger_behavior = true,
            scroll_factor = 0.7
        }
    },

    misc = {
        disable_hyprland_logo = true,
        disable_splash_rendering = true,
        vrr = 0,
        mouse_move_enables_dpms = true,
        key_press_enables_dpms = true,
        animate_manual_resizes = false,
        animate_mouse_windowdragging = false,
        enable_swallow = false,
        swallow_regex = "(foot|kitty|allacritty|Alacritty)",
        on_focus_under_fullscreen = 2,
        allow_session_lock_restore = true,
        session_lock_xray = true,
        initial_workspace_tracking = false,
        focus_on_activate = true
    },

    binds = {
        scroll_event_delay = 0,
        hide_special_on_workspace_change = true
    },

    cursor = {
        zoom_factor = 1,
        zoom_rigid = false,
        zoom_disable_aa = true,
        hotspot_padding = 1,
        no_hardware_cursors = true
    },

    xwayland = {
        force_zero_scaling = true
    }
})
